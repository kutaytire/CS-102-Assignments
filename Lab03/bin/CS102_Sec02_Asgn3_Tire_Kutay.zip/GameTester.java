import java.util.*;

public class GameTester {

    public static void main( String[] args) {

        Scanner scan = new Scanner(System.in);

        System.out.println("Please enter the difficulty: ");
        int dif = scan.nextInt();

        Game game = new Game(dif);

        game.play();

        
        
        scan.close();
    }
    
}
