

public class Point {

    // Properties

    private int x;
    private int y;

    // Constructor

    public Point(int theX, int theY) {

        x = theX;
        y = theY;
    }

    // Methods

    public int getX() {

        return x;
    }

    public int getY() {

        return y;
    }

    
    
}
